public class Variable {
    
    
}
